import "./App.css";
import LifecycleClass from "./components/lifecycle/LifecycleClass";
import LifecycleFunctional from "./components/lifecycle/LifecycleFunctional";

function App() {
  return (
    <div className="App">
      <h1>Component Lifecycle</h1>
      <hr></hr>
      <LifecycleFunctional />
      <LifecycleClass />
    </div>
  );
}

export default App;
