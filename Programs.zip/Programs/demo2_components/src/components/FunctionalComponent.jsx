import React from "react";

function FunctionalComponent() {
  return (
    <div>
      <h1>Hello world!</h1>
    </div>
  );
}

export default FunctionalComponent;
