import React from "react";

function About() {
  return (
    <div>
      <h1>About</h1>
      <hr></hr>
      <p>This is my about page</p>
    </div>
  );
}

export default About;
