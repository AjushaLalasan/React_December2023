import React from "react";

function Home() {
  return (
    <div>
      <h1>Home</h1>
      <hr></hr>
      <p>This is my home page</p>
    </div>
  );
}

export default Home;
