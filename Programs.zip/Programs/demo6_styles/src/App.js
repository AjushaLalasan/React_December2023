import "./App.css";
import Inlinestyles from "./components/inlinestyles/Inlinestyles";

function App() {
  return (
    <div className="App">
      <Inlinestyles />
    </div>
  );
}

export default App;
