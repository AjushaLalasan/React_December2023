import React from "react";

function Inlinestyles() {
  const myStyle = {
    backgroundColor: "lightgrey",
    padding: 20,
    border: 1,
    borderRadius: 5,
  };
  return (
    <div>
      <h1 style={{ color: "green" }}>Inlinestyles</h1>
      <hr></hr>
      <div>
        <p style={myStyle}>The paragraph goes here.</p>
      </div>
    </div>
  );
}

export default Inlinestyles;
