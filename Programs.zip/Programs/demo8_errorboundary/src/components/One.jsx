import React from "react";

function One() {
  return <div>One</div>;
}

export default One;
