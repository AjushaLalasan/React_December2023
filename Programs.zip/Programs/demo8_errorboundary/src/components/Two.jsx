import React from "react";
import { useEffect } from "react";

function Two() {
  useEffect(() => {
    throw new Error("error");
  });
  return <div>Two</div>;
}

export default Two;
