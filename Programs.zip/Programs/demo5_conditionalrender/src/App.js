import "./App.css";
import ConditionalRender from "./components/ConditionalRender";

function App() {
  return (
    <div className="App">
      <h1>Conditional Rendering</h1>
      <hr></hr>
      <ConditionalRender />
    </div>
  );
}

export default App;
