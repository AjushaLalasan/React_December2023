import React from "react";

function Home() {
  return (
    <div>
      <h3>Hi User</h3>
    </div>
  );
}

export default Home;
