import React from "react";

function Guest() {
  return (
    <div>
      <h3>Hi Guest</h3>
    </div>
  );
}

export default Guest;
