import React, { useState } from "react";
import Home from "./Home";
import Guest from "./Guest";

function ConditionalRender() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const handleClick = () => {
    setIsLoggedIn(true);
  };
  return (
    <div>
      {isLoggedIn ? <Home /> : <Guest />}
      {!isLoggedIn && <button onClick={handleClick}>Login</button>}
    </div>
  );
}

export default ConditionalRender;
