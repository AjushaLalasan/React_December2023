import React from "react";
import "./Signup.css";
import Paper from "@mui/material/Paper";
import {
  Box,
  Button,
  FormControl,
  Grid,
  TextField,
  Typography,
} from "@mui/material";

function Signup() {
  return (
    <Grid>
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "90vh",
        }}
      >
        <Paper elevation={3} sx={{ width: 500, height: 570 }}>
          <Typography variant="h4" sx={{ marginBottom: 3, marginTop: 3 }}>
            Sign Up
          </Typography>
          <FormControl sx={{ marginBottom: 2, width: 350 }}>
            <TextField label="Name" margin="normal" />
          </FormControl>
          <FormControl sx={{ marginBottom: 2, width: 350 }}>
            <TextField label="Username" margin="normal" />
          </FormControl>
          <FormControl sx={{ marginBottom: 2, width: 350 }}>
            <TextField label="Password" type="password" margin="normal" />
          </FormControl>
          <FormControl sx={{ marginBottom: 2, width: 350 }}>
            <TextField
              label="Confirm Password"
              type="password"
              margin="normal"
            />
          </FormControl>
          <Button variant="contained" color="secondary" sx={{ width: 350 }}>
            Submit
          </Button>
        </Paper>
      </Box>
    </Grid>
  );
}

export default Signup;
