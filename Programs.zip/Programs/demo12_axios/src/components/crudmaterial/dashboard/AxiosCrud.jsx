import React, { useEffect, useState } from "react";
import axios from "axios";
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  TextField,
} from "@mui/material";

function AxiosCrud() {
  const [users, setUsers] = useState([]);
  const [newUser, setNewUser] = useState({ name: "" });
  const [editUser, setEditUser] = useState(null);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      const response = await axios.get("http://localhost:3001/users");
      setUsers(response.data);
    } catch (error) {
      console.error("Error fetching users:", error);
    }
  };

  const handleAdd = async () => {
    try {
      const response = await axios.post("http://localhost:3001/users", newUser);
      setUsers((prevUsers) => [...prevUsers, response.data]);
      setNewUser({ name: "" });
    } catch (error) {
      console.error("Error adding user:", error);
    }
  };

  const handleEdit = (user) => {
    setEditUser(user);
  };

  const handleSave = async () => {
    try {
      await axios.put(`http://localhost:3001/users/${editUser.id}`, editUser);
      setEditUser(null);
      fetchUsers(); // Refresh the user list after edit
    } catch (error) {
      console.error("Error updating user:", error);
    }
  };

  const handleDelete = async (userId) => {
    try {
      await axios.delete(`http://localhost:3001/users/${userId}`);
      setUsers((prevUsers) => prevUsers.filter((user) => user.id !== userId));
    } catch (error) {
      console.error("Error deleting user:", error);
    }
  };

  const handleCancel = () => {
    setEditUser(null);
  };

  const handleInputChange = (e, field) => {
    if (editUser) {
      setEditUser((prevUser) => ({
        ...prevUser,
        [field]: e.target.value,
      }));
    } else {
      setNewUser({ [field]: e.target.value });
    }
  };

  return (
    <div style={{ textAlign: "center" }}>
      <h1>User List</h1>
      <TableContainer
        component={Paper}
        style={{ maxWidth: "700px", margin: "auto" }}
      >
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>ID</TableCell>
              <TableCell>NAME</TableCell>
              <TableCell>ACTIONS</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {users.map((user) => (
              <TableRow key={user.id}>
                <TableCell>{user.id}</TableCell>
                {editUser && editUser.id === user.id ? (
                  <>
                    <TableCell>
                      <TextField
                        value={editUser.name}
                        onChange={(e) => handleInputChange(e, "name")}
                      />
                    </TableCell>
                    <TableCell>
                      <Button onClick={handleSave}>Save</Button>
                      <Button onClick={handleCancel}>Cancel</Button>
                    </TableCell>
                  </>
                ) : (
                  <>
                    <TableCell>{user.name}</TableCell>
                    <TableCell>
                      <Button onClick={() => handleEdit(user)}>Edit</Button>
                      <Button onClick={() => handleDelete(user.id)}>
                        Delete
                      </Button>
                    </TableCell>
                  </>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <h2>Add User</h2>
      <TextField
        type="text"
        placeholder="Name"
        value={newUser.name}
        onChange={(e) => handleInputChange(e, "name")}
      />
      <Button onClick={handleAdd}>Add</Button>
    </div>
  );
}

export default AxiosCrud;
