import React, { useEffect, useState } from "react";
import axios from "axios";

function AxiosGet() {
  const [users, setUsers] = useState([]);
  useEffect(() => {
    axios.get(`http://localhost:3001/users`).then((res) => {
      setUsers(res.data);
    });
  }, []);
  return (
    <div>
      <h3>User Details</h3>
      <ul style={{ listStyle: "none" }}>
        {users.map((user) => (
          <li key={user.id}>{user.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default AxiosGet;
