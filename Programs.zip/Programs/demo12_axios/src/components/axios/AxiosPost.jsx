import axios from "axios";
import React, { useState } from "react";

function AxiosPost() {
  const [name, setName] = useState("");
  const handleChange = (event) => {
    setName(event.target.value);
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    axios.post(`http://localhost:3001/users`, { name }).then((res) => {
      console.log(res.data);
    });
  };
  return (
    <div>
      <h3>Add user</h3>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={name}
          onChange={handleChange}
          placeholder="Enter user's name"
        ></input>
        <button type="submit">Add</button>
      </form>
    </div>
  );
}

export default AxiosPost;
