import axios from "axios";
import React, { useState } from "react";

function AxiosDelete() {
  const [id, setId] = useState();
  const handleId = (event) => {
    setId(event.target.value);
  };
  const handleSubmit = (event) => {
    event.preventDefault();
    axios.delete(`http://localhost:3001/users/${id}`).then((res) => {
      console.log(res.data);
      console.log(`Deleted ID: ${id}`);
    });
  };
  return (
    <div>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={id}
          onChange={handleId}
          placeholder="Enter user's id"
        ></input>
        <button type="submit">Delete</button>
      </form>
    </div>
  );
}

export default AxiosDelete;
