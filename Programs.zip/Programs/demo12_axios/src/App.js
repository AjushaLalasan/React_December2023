import "./App.css";
import Signup from "./components/crudmaterial/Signup";

function App() {
  return (
    <div className="App">
      <Signup />
    </div>
  );
}

export default App;
