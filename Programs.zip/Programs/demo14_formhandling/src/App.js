import "./App.css";
import DynamicInput from "./components/dynamicinput/DynamicInput";

function App() {
  return (
    <div className="App">
      <DynamicInput />
    </div>
  );
}

export default App;
