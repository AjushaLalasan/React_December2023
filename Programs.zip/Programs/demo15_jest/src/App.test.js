import { render, screen } from "@testing-library/react";
import App from "./App";

test("renders heading React App", () => {
  render(<App />);
  const linkElement = screen.getByText(/React Test - JEST/i);
  expect(linkElement).toBeInTheDocument();
});
test("renders textbox", () => {
  render(<App />);
  const textInput = screen.getByRole("textbox");
  expect(textInput).toBeInTheDocument();
});
test("renders button", () => {
  render(<App />);
  const button = screen.getByRole("button");
  expect(button).toBeInTheDocument();
});
