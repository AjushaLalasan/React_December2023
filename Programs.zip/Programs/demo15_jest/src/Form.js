import React from "react";

function Form() {
  return (
    <div>
      <h1>React Test - JEST</h1>
      <input type="text"></input>
      <button>Submit</button>
    </div>
  );
}

export default Form;
