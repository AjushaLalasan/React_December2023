import PropTypes from "prop-types";
function PropsDemo({ username }) {
  return (
    <div>
      <h3>username: {username}</h3>
    </div>
  );
}

PropsDemo.propTypes = {
  username: PropTypes.string,
};

PropsDemo.defaultProps = {
  username: "Johns",
};
export default PropsDemo;
