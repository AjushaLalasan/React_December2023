import { Component } from "react";

class StateClass extends Component {
  constructor(props) {
    super(props);
    this.state = {
      username: "John",
    };
  }
  usernameHandler = () => {
    this.setState({ username: "Mike" });
  };
  render() {
    return (
      <div>
        <h3>username : {this.state.username}</h3>
        <button onClick={this.usernameHandler}>Click to change username</button>
      </div>
    );
  }
}

export default StateClass;
