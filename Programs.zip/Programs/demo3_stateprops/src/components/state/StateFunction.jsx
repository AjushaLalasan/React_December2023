import { useState } from "react";

function StateFunction() {
  const [username, setUsername] = useState("John");
  const usernameHandler = () => {
    setUsername("Mike");
  };
  return (
    <div>
      <h3>username : {username}</h3>
      <button onClick={usernameHandler}>Click to change username</button>
    </div>
  );
}

export default StateFunction;
