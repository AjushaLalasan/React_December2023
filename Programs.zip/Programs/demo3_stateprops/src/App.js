import "./App.css";
import PropsDemo from "./components/props/PropsDemo";
import StateClass from "./components/state/StateClass";
import StateFunction from "./components/state/StateFunction";
function App() {
  return (
    <div className="App">
      <h1>State and Props</h1>
      <hr></hr>
      <StateFunction />
      <StateClass />
      <PropsDemo username="Tom" />
    </div>
  );
}

export default App;
