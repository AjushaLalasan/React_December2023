import "./App.css";
import Component1 from "./components/context/Component1";

function App() {
  return (
    <div className="App">
      <h1>Context</h1>
      <hr></hr>
      <Component1 />
    </div>
  );
}

export default App;
