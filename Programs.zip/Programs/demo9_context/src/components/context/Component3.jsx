import React, { useContext } from "react";
import UserContext from "./UserContext";

function Component3() {
  const user = useContext(UserContext);
  return (
    <div>
      <h3>component 3 called - Hi {user}</h3>
    </div>
  );
}

export default Component3;
