import React from "react";
import Component3 from "./Component3";

function Component2() {
  return (
    <div>
      <h3>component 2 called</h3>
      <Component3 />
    </div>
  );
}

export default Component2;
