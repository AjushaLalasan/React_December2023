import React, { useState } from "react";
import UserContext from "./UserContext";
import Component2 from "./Component2";

function Component1() {
  const [user] = useState("Mike");
  return (
    <UserContext.Provider value={user}>
      <h3>component 1 called</h3>
      <Component2 />
    </UserContext.Provider>
  );
}

export default Component1;
