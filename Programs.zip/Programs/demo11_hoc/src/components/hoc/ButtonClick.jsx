import withCounter from "./withCounter";

const ButtonClick = ({ count, onIncrement }) => {
  return (
    <div>
      <button onClick={onIncrement}>Clicked {count} times</button>
    </div>
  );
};

export default withCounter(ButtonClick);
