import withCounter from "./withCounter";

const MouseOver = ({ count, onIncrement }) => {
  return (
    <div>
      <h1 onMouseOver={onIncrement}>Count: {count}</h1>
    </div>
  );
};

export default withCounter(MouseOver);
