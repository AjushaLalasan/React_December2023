import React, { useState } from "react";

function MouseOver() {
  const [count, setCount] = useState(0);
  const handleMouseOver = () => {
    setCount(count + 1);
  };
  return (
    <div>
      <h1 onMouseOver={handleMouseOver}>Count: {count}</h1>
    </div>
  );
}

export default MouseOver;
