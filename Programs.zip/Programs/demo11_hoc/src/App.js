import ButtonClick from "./components/hoc/ButtonClick";
import MouseOver from "./components/hoc/MouseOver";
import "./App.css";

function App() {
  return (
    <div className="App">
      <h1>HOC - Higher Order Component</h1>
      <hr></hr>
      <ButtonClick />
      <MouseOver />
    </div>
  );
}

export default App;
