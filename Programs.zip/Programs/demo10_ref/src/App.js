import "./App.css";
import LoginForm from "./components/useref/LoginForm";
import Usecase1 from "./components/useref/Usecase1";
import Usecase2 from "./components/useref/Usecase2";

function App() {
  return (
    <div className="App">
      <h1>useRef - Usecase</h1>
      <hr></hr>
      <Usecase1 />
      <Usecase2 />
      <LoginForm />
    </div>
  );
}

export default App;
